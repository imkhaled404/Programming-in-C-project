class ClassTable{
    public:
        wxString table_name;
        void setTable(wxString tb){
            table_name=tb;
        }
        ClassTable(){};
    
};


