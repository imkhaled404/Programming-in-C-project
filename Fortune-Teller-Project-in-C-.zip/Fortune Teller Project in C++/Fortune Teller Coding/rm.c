#include <stdio.h>
#include <stdlib.h>
int main(){
        system("ren aa.txt temp.txt");
    return 0;
}
